<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Multiples Of 5</title>
</head>
<body>
	<?php
		for( $i = 5; $i <= 1000000; $i += 5 ) {
			echo $i . "<br>";
		}
	?>
</body>
</html>